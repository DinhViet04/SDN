const express = require('express');
const router = express.Router();
const {
    apiGetAllBookings, createBooking, updateBooking, deleteBooking
} = require('../controllers/bookingController');

// Set API flag for all routes in this router
router.use((req, res, next) => { req.isApi = true; next(); });

router.get('/', apiGetAllBookings);
router.post('/', createBooking);
router.put('/:id', updateBooking);
router.delete('/:id', deleteBooking);

module.exports = router;
