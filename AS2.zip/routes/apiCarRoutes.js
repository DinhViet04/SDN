const express = require('express');
const router = express.Router();
const {
    apiGetAllCars, createCar, updateCar, deleteCar
} = require('../controllers/carController');

// Set API flag for all routes in this router
router.use((req, res, next) => { req.isApi = true; next(); });

router.get('/', apiGetAllCars);
router.post('/', createCar);
router.put('/:id', updateCar);
router.delete('/:id', deleteCar);

module.exports = router;
